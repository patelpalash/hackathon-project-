# Transport Lead-Time Planner: hackathon prototype plan

**Implementation handoff:** the detailed, frozen version-1 specification is in [docs/START_HERE.md](docs/START_HERE.md). It includes the exact OpenAPI contract, synthetic network, checked numerical fixtures, routing rules, UI behavior, two-person work packages and separate coding prompts. Its explicit version-1 decisions supersede tentative technical choices below; this document remains the business overview.

Prepared from the supplied ten-page PDF, challenge photograph and seven CSV files. Confirmed team: two people using React/TypeScript and Python, one assisted by Codex and the other by Claude/Antigravity. Remaining time is unconfirmed, so the timetable assumes two hackathon days. Updated scope includes automatic disruption recalculation and manager review (section 13). This document is a plan; the application has not been implemented.

## 1. Problem in plain English

DACHSER needs to answer: "If goods are ready at location A at this time, when can they reach B, through which connections, and why?"

A distance or a fixed "two days" promise does not account for scheduled departures, missed cut-offs, hub processing, customs, connecting services, closed days or unavailable lanes. The prototype must combine those steps into an explainable arrival estimate and offer feasible alternative routes.

The brief's illustrative Istanbul-to-Kempten shipment has a static assumption of 48 hours and a composed lead time of 70 hours: pickup 4 + departure handling 6 + air transport 3 + hand-over/customs 14 + hub processing 8 + line haul 6 + restriction waiting 24 + delivery 5. These are example values from the brief, not measured performance. A 24-hour restriction delay must not be added to every Sunday shipment automatically; calculate the actual overlap with the configured demo rule.

Terms: a node is a place; a lane is a directed connection; line haul is a scheduled service between facilities; hand-over is a transfer between operators or transport modes; cut-off is the latest acceptance time for a departure.

## 2. What the supplied data can support

Counts exclude header rows.

| File | Rows | Meaning | Prototype use and limits |
|---|---:|---|---|
| disposition.csv | 19,980 | Daily planning and outcomes, 30 relations over 666 dates, 2024-01-02 to 2026-08-31 | Historical route volume and capacity context. Contains no shipment departure/arrival timestamps. |
| relationen.csv | 30 | Destination branch, km, trailer costs, capacity, target utilization | Destination catalog and explicitly mapped lane metadata. No origin, intermediate stops or timetable. |
| kalender.csv | 1,050 | Dates, weekday, working day, Baden-Wuerttemberg holidays, school/automotive breaks, commercial dates; 2024-01-01 to 2026-11-15 | Local calendar context; working day is not automatically a transport operating day. Cannot stand in for every country or German region. |
| stoerungen.csv | 7 | Historical weather, strike, system and handling disruptions | Historical context. Numeric effects describe volume, not travel-time delay. New delay scenarios require explicit separate assumptions. |
| kundenstamm.csv | 820 | Customer segments, industries, sizes and contract dates | Optional context; no customer-to-route or shipment-volume mapping. |
| kundensignale.csv | 72 | Customer announcements and effective dates | Optional dated signals panel. Percentage changes cannot be assigned to lanes without a customer-to-lane baseline. |
| vertriebsereignisse.csv | 188 | Customer starts/losses and sales events | Optional context; not needed for the core transit-time calculation. |

Verified joins: all disposition relation IDs exist in relationen; all disposition dates exist in kalender; all signal customers exist in kundenstamm; sales customer references exist except the intentional ALLE (all customers) value. No duplicate disposition date/relation keys or fully duplicate CSV rows were found. This is a structural check, not complete semantic validation.

Useful example: R01 is Hamburg, with 600 km, 13.6 loading metres per trailer and a 92% utilization target. On 2024-01-04, disposition records four planned trailers, five needed, one special trip and 55.5 loading metres. Four trailers hold 54.4 loading metres; five hold 68, and 55.5 / 68 is approximately the recorded 81.6% utilization. This explains capacity pressure but does not establish an arrival time.

Data cautions: 31 records have top30=1; treat it as the supplied flag rather than silently changing it. Three signals have no end date; keep their duration unknown until a documented convention is chosen. Future announcements must not appear as known before meldung_datum. Historical operating data ends before the current hackathon date; display its coverage prominently.

## 3. Missing inputs and a practical response

Missing: origins and route topology, branch coordinates, time zones, scheduled departures, arrival durations, validity dates, cut-offs, transfer times, country/region rules, shipment history and first/last-mile service calendars. Distances alone cannot supply these facts.

Build an explicit demo seed for three countries (Germany, France, Turkey), approximately 10 nodes and 16 directed lanes. Include at least two paths for the main demonstration. Use one road chain and one air-to-road chain with an airport hand-over. A sea example is optional. The brief permits simplifications; these counts are our proposal, not mandated numbers.

Retain the 30 imported destinations as source records, but expose only mapped, connected nodes as routable. Never invent connectivity among all 30 destinations. If Heilbronn is selected as a demo origin, mark it as an assumption: relationen does not specify it.

Every seeded duration, departure, coordinate, origin mapping and restriction has provenance: supplied CSV, supplied brief example, or demo assumption. Give the GUI a Data & assumptions drawer and mark estimates as based on demo schedules. Request actual schedules and events from the representative if available, without blocking the permitted mock prototype.

## 4. Definition of the working prototype

Required demonstration:

1. Enter origin, destination, shipment-ready date/time and a service preference.
2. Calculate feasible routes using the current saved schedule.
3. Show up to three distinct feasible routes, sorted by arrival time, with transfer count and total duration. Return fewer if fewer exist.
4. Select a route to see its network path and ordered travel/handling/waiting timeline.
5. Explain each wait in ordinary language, such as "Cut-off missed; next departure Monday 18:00".
6. Edit a departure, lane validity, active status or hand-over time; persist it and recalculate.
7. Show an explicit no-feasible-route result when appropriate.
8. Reset the demo and export a human-readable itinerary through browser printing.
9. Ingest structured weather, traffic and operational/border events from a labeled demo feed; automatically recalculate affected plans and explain suggested alternatives.
10. Let a manager report a scoped disruption, review a route recommendation and accept/reject it with a reason; preserve the calculation and decision history.

Use a desktop-first GUI with three views:

| View | Controls and content |
|---|---|
| Route planner | Search form; route comparison cards; geographic overview or location schematic; selected-route timeline; arrival date/time and time zone; explanation and assumptions drawer. |
| Network & schedules | Typed nodes for branches, hubs and hand-overs; directed road/air/sea lanes; table/detail editor for schedules, cut-offs, duration, validity and status. |
| Scenarios & data | Baseline-versus-change comparison; disruption feed and manager review queue; missed cut-off, weather/traffic, border closure and extended customs presets; CSV coverage and historical volume context. |

Make arrival date/time the most prominent result. Use blue for travel, amber for handling, and a clearly labeled red wait state; do not rely on color alone. A selected route must highlight consistently in cards, map and timeline. Display local times with zone labels and keep elapsed hours separate from calendar dates.

A small geographic view can use an offline bundled SVG with demo coordinates. Curved lines are schematic connections, not verified road geometry. React Flow provides the editable network view. Avoid making the judge demo depend on live map tiles.

Defer live GPS, full commercial pricing, national network completeness, production authentication, customer-demand forecasting and production TMS integrations. These are outside the core proof. Implement scenario changes as temporary overrides unless explicitly saved. Manager review uses a clearly labeled demo identity; production roles require backend authentication and authorization. Section 13 defines persistent disruption events separately from temporary scenarios.

## 5. Recommended technology

| Layer | Choice | Reason |
|---|---|---|
| Browser app | React + TypeScript + Vite | Suitable for forms, linked views and a custom presentation; Vite has a React/TypeScript template. |
| Styling | CSS modules and a small shared component set | Keep dependencies and setup modest; use existing team components if available. |
| Network view | @xyflow/react (React Flow) | Interactive custom nodes, edges and selection. |
| Timeline and map | React/SVG components | Exact control of step labels and offline rendering. |
| API and calculation | Python + FastAPI + Pydantic | Typed requests, validation, automatic API documentation; convenient CSV processing. |
| Persistence | SQLite through Python sqlite3 | Local persistent schedules and easy reset/backup without a database server. |
| Import/analysis | pandas | Parse and join supplied CSVs; preserve source columns. |
| Time handling | Python datetime + zoneinfo, with tzdata available on Windows | Timezone-aware scheduling; store timestamps in UTC, retain local schedule zones. |
| Verification | pytest for routing/calendar logic; browser end-to-end checks | Verify time arithmetic and the complete edit/recalculate workflow. |
| Demo delivery | Local FastAPI process serving the built frontend and API | One launch command and an offline-capable judge demo; hosted deployment can follow. |

The core engine is deterministic. An LLM is unnecessary for computing times; generated explanations should come from structured calculation reasons. Future learned durations need actual timestamped journey data and evaluation. Do not report prediction confidence or accuracy from the current CSVs.

If the team is JavaScript-only, keep the same GUI and model but implement the API and engine in TypeScript to avoid learning Python during the event. The recommended stack assumes both languages are comfortable. Pin working dependency versions during implementation.

Official references checked for this plan: [Vite](https://vite.dev/guide/), [React Flow custom nodes](https://reactflow.dev/learn/customization/custom-nodes), [FastAPI](https://fastapi.tiangolo.com/), [SQLite use cases](https://www.sqlite.org/whentouse.html).

## 6. Minimal data model

| Entity | Key fields |
|---|---|
| node | id, name, type, country, region, latitude, longitude, timezone, processing_minutes, active, provenance |
| lane | id, from_node, to_node, mode, distance_km, duration_minutes, active, valid_from, valid_to, provenance |
| departure_rule | id, lane_id, local_departure_time, weekdays, timezone, cutoff_minutes, valid_from, valid_to |
| calendar_rule | id, scope, local blocked interval or recurrence, affected mode/activity, action, provenance |
| service_profile | id, allowed_modes, max_transfers, optional arrival deadline, explicit handling policy |
| source_relation_mapping | source relation ID, mapped lane ID, origin assumption and review note |
| daily_operations | datum + relation key and original disposition measures |
| scenario | id, name, lane/node/rule overrides, base schedule revision |

Retain the raw CSVs unchanged. Store all calculated durations in minutes. Calendar scopes distinguish country, region, node and mode. Scheduled dates are interpreted in the departure location's time zone; validity boundaries must have an explicit documented inclusive/exclusive convention.

## 7. Calculation design

For a small demo network, enumerate cycle-free paths within a documented five-lane limit and simulate their eligible service connections over a 14-day horizon. Evaluate feasible departure alternatives, not simply the first departure when later services could arrive earlier. Return the earliest-arriving itinerary per path and select up to three distinct paths. Report these bounds; a result outside the horizon is "no route within the search window".

At each node/lane:

1. Determine arrival at the node and apply the required handling exactly once.
2. Apply the node's opening/processing calendar if configured; obtain ready-to-transfer time.
3. Enumerate departures that satisfy operating weekday, lane/departure validity and the cut-off. Define cut-off equality explicitly; proposal: ready time equal to cut-off is accepted.
4. Check scoped operating restrictions. For a fixed service that is cancelled by a rule, skip that occurrence and find another. Only shift a departure if the configured rule explicitly permits it.
5. Calculate travel using the seeded elapsed duration. When a demo rule pauses road travel, calculate actual overlap with blocked intervals, including restrictions encountered after departure. Avoid adding a fixed 24 hours by default.
6. Apply the next transfer and service constraints. If a connection is missed, take a later feasible one or reject the path.
7. Include final handling/local delivery only if present in the chosen service scope.

Total lead time = final arrival UTC - original ready time UTC.

Return segments with category, node/lane ID, start/end UTC, local display zone, duration, reason code, readable explanation and provenance. Segment durations must sum to elapsed time without unexplained gaps or overlapping waits. Treat road, airport and hand-over activities separately; an airport is not closed merely because a road-truck restriction applies.

Any example restriction is a configurable simulation assumption, not a claim of complete current legal compliance. Driver-hours compliance, permits and exact roadway routing require additional data and remain documented simplifications.

## 8. API and project structure

Suggested endpoints:

- GET /api/network: nodes, lanes and schedule revision.
- GET /api/lanes and PATCH /api/lanes/{id}: inspect/edit lane and timetable data.
- PATCH /api/nodes/{id}: update hand-over/handling settings.
- POST /api/routes/search: origin, destination, zoned ready time, service profile and optional scenario overrides; returns itineraries and explanations.
- GET /api/data-summary: source coverage, mappings and assumptions.
- POST /api/demo/reset: restore documented seed state for the demo.

Reject invalid dates, negative durations, unknown nodes and inconsistent validity ranges. Do not silently coerce missing data into zero-duration travel. Recalculate from one backend engine for every view so map, timeline and results agree. Invalidate displayed results whenever an input or schedule revision changes.

Suggested directories: frontend/src/{components,pages,api,types}; backend/app/{api,models,services,imports}; backend/tests; data/{raw,demo}; docs. Maintain a README with setup, launch, reset, assumptions and demo steps. Do not copy source datasets into public hosting by default.

## 9. Two-day implementation sequence

These are focused work blocks, not a promise of 48 continuous working hours. Person A uses Codex for the GUI and integration. Person B uses Claude/Antigravity for the engine, data and API. Both agree on the response format first and share final acceptance checks and the pitch.

| Block | Work | Completion checkpoint |
|---|---|---|
| Day 1, first 2 hours | Confirm service boundaries; seed nodes, two alternative paths, time zones, departures and provenance; agree API shape. | One hand-calculated itinerary and mock API response agreed. |
| Day 1, next 3 hours | Build working end-to-end form -> API -> single-route computation -> timeline. | One real search works in the browser. |
| Day 1, next 3 hours | Add alternative paths, cut-offs, calendars, hand-overs and core unit tests; build linked network and route cards. | Changing ready time changes connections and arrival correctly. |
| Day 2, first 2 hours | Add persistent schedule/status editor, structured demo disruption feed, automatic recalculation and manager decision persistence. | Traffic/weather or closure changes the recommendation; manager decision survives reload. |
| Day 2, next 2 hours | Complete event/report/review controls, no-route/validation states and data drawer. Defer customer panels and general topology editing if necessary. | Every main control works; reasons, event freshness and assumptions can be inspected. |
| Day 2, next 2 hours | Run acceptance cases, fix failures, package local launch/reset and capture a backup demo recording. | Fresh launch works without external network services. |
| Final 1-2 hours | Freeze features, rehearse a three-minute pitch and document limitations. | Repeatable judge demonstration with no manual repair. |

If fewer than eight hours remain, narrow to one seeded origin/destination pair with two paths, one cut-off rule, one hand-over, one closure toggle and an accurate timeline. Keep the time calculation, editing and visible assumptions. Defer customer panels, general topology editing and additional modes.

## 10. Acceptance checks

- Catch a service before cut-off; equality follows the documented boundary; miss it just after cut-off.
- Correctly roll over midnight, weekends and the configured holiday/blocked intervals.
- Do not apply a regional or road-only restriction to an unrelated location or air leg.
- Propagate extra hand-over time into a missed connection and later arrival.
- Reject inactive and expired lanes; preserve edits after reload.
- Handle multiple scheduled services between the same nodes and return valid alternatives.
- Distinguish disconnected network from search-horizon exhaustion where possible.
- Verify one Turkey/Germany timezone conversion and a daylight-saving boundary; reject ambiguous local inputs or require an explicit offset.
- Verify monotonic segment timestamps, exact sum of durations, and no double counting of waiting and handling.
- Verify map, route cards and timeline describe the same selected result and revision.
- Check source CSVs remain unchanged; import summaries reconcile to the row counts above.
- Confirm demonstration works after reset and when internet access is unavailable.

Success measures: all critical checks pass; a proposed target of under two seconds per search on the tiny seeded network; every wait has a reason; no unsupported route or accuracy claim. Runtime performance is a target until measured.

## 11. Judge demonstration

1. Explain the problem: a fixed delivery promise hides missed departures and hand-over time.
2. Search a seeded shipment and compare two valid options.
3. Open the timeline to explain why the selected arrival is plausible.
4. Change readiness to miss a cut-off; show the next connection and changed promise.
5. Introduce a weather/traffic delay or border closure through the labeled demo feed; show automatic recalculation and an alternative or honest no-route result. A manager accepts or rejects the proposed route with a reason; show the decision history.
6. Reveal the assumptions drawer and briefly show how the supplied files enrich the model.

Pitch sentence: "We turn transport schedules into delivery estimates that show every connection, every wait and every alternative."

Deliver the working local GUI, source code, editable seed data, short assumptions/architecture notes, tests and a three-minute pitch. Describe the result as a schedule-based planning prototype. Real-time tracking and measured ETA accuracy require integrations and timestamped operational data that were not supplied.

## 12. Two-person ownership and integration agreement

| Owner | Agent tools | Owns | Must deliver |
|---|---|---|---|
| Person A | Codex | frontend/**, GUI interactions, API client, root launch/readme integration | Search, route cards, network view, timeline, schedule editor, scenarios, assumptions, browser verification and demo packaging. |
| Person B | Claude/Antigravity | backend/**, data/**, backend tests | Validated CSV import, documented synthetic network, SQLite persistence, API, deterministic scheduling, explanations and tested edge cases. |
| Both | Human agreement before coding | API contract and demo scope | Fixed request/response names, IDs, units, time conventions, sample expected itinerary and three demo stories. |

Person A is the integration owner and edits shared root files and docs/api-contract.md after both agree. Person B proposes contract changes before modifying backend responses. Each developer works on a separate branch/checkout (suggested names codex/frontend and backend-routing); merge small working increments. Do not let two coding agents edit the same checkout or file concurrently. If Claude and Antigravity are both active for Person B, designate one as the writer and use the other to review/test, or isolate their branches.

First 30 minutes together: agree branch-to-branch versus door-to-door service scope, choose one two-path scenario, and calculate its expected timestamps by hand. Start with branch-to-branch for the first working version; add explicitly modeled pickup/delivery segments for the full example later. Always label the scope in the GUI.

Next 30 minutes: Person A saves the API contract and frontend fixture; Person B implements GET /api/health and POST /api/routes/search for one route. The frontend fixture must match the contract and be visibly labeled Demo fixture while in use. It is a temporary development aid and must be replaced by backend responses before claiming the GUI calculates routes.

Integrate at three checkpoints: a working real API search on Day 1; a schedule edit that changes the computed result by Day 2 morning; a fresh-start full demo before the final polish block. Avoid leaving frontend/backend connection until the last hour.

### Shared contract decisions

- Prefix all endpoints with /api. Use a Vite development proxy to the Python server; in the packaged demo serve frontend and API from one origin.
- Request ready_at is ISO 8601 with an explicit offset. Responses use UTC timestamps and include node time zones. All duration fields are integer minutes.
- Search request fields: origin_id, destination_id, ready_at, service_profile_id, max_results (up to 3), scenario_overrides (optional).
- Search response fields: schema_version, schedule_revision, scope, status, search_horizon_end, routes, warnings. status distinguishes ok from no_feasible_route; validation uses a documented error response.
- Each route: id, node_ids, lane_ids, departure_at, arrival_at, total_minutes, transfer_count, segments, assumptions.
- Each segment: id, type (handling/wait/travel/pickup/delivery), node_id or lane_id, start_at, end_at, duration_minutes, reason_code, explanation, provenance.
- GET /api/network includes nodes, lanes and departure rules with stable IDs; historical relation IDs and routable lane IDs are different fields linked by explicit mappings.
- PATCH operations return the saved entity and new schedule_revision. Frontend must mark old routes stale and request new results after a saved change.
- No-route results carry an empty routes list and readable reasons, not a fabricated itinerary or generic server error.
- Scenario overrides do not persist. Saving a lane edit does persist. Reset restores the original seed.

Shared arithmetic fixture: ready 2026-09-21T08:00:00Z; handling until 10:00Z (120 min); wait until 16:00Z (360 min); travel until 22:00Z (360 min); total 840 min, or 14 hours. This is a synthetic branch-to-branch contract fixture with no extra delivery segment, not a measured journey. Both agents must render/calculate the same result.

### Person A: copy-ready Codex prompt

> Build the frontend for the transport lead-time hackathon prototype described in PROTOTYPE_PLAN.md. I own frontend/** and root integration files; another teammate owns backend/** and data/**. Read the agreed docs/api-contract.md before implementation and do not change backend files. Use React, TypeScript, Vite, React Flow and CSS. Build a route search, up to three route cards, selected-route network/map, detailed timeline, lane/schedule editor, scenario controls, and data/assumptions drawer. Show time zones, service scope, source provenance, loading, invalid-input and no-route states. Start with a visibly labeled contract fixture, then connect every calculation and save action to the Python API. The backend is the source of calculated times. Confirm that changing ready time and disabling a lane actually changes returned results. Verify the full flow in the browser, including persistence after reload. Keep work within the agreed scope and deliver a reliable local demo plus launch instructions.

### Person B: copy-ready Claude/Antigravity prompt

> Build the backend for the transport lead-time hackathon prototype described in PROTOTYPE_PLAN.md. I own backend/** and data/**; another teammate owns the React frontend and root integration files. Read and implement docs/api-contract.md exactly; propose API changes before applying them. Use Python, FastAPI, Pydantic, SQLite, pandas and timezone-aware datetime/zoneinfo with tzdata. Inspect the supplied CSVs and preserve them unchanged. They contain daily capacity/volume data, not departure schedules or measured transit times. Create a small explicitly synthetic directed network with branches, hubs, hand-overs, departure rules, cut-offs, validity, active status and scoped example restrictions. Implement deterministic time-dependent route simulation, up to three distinct feasible paths, structured segment explanations, persistent schedule edits, temporary scenario overrides, data summary, health and demo reset. Treat missing or unsupported routes honestly. Test missed cut-offs, expired/closed lanes, hand-over delays, local calendars, timezone conversion, no-route results and exact duration reconciliation. Deliver runnable API endpoints and a seed reset command; do not modify frontend/**.

Use these prompts after the shared contract exists. They are work assignments for your two separate coding sessions; this planning task has not started either implementation agent.

## 13. Automatic disruption handling and human review

### Product behavior

The engine automatically estimates arrivals and recomputes affected plans when accepted event data changes. A manager can supply information the system lacks and review operational route changes. Recalculation does not wait for a manager; changing a committed dispatch plan does. The prototype records a planning decision and does not dispatch vehicles or contact customers.

Support these event types through one shared mechanism:

| Input | Structured impact | Engine response |
|---|---|---|
| Bad weather | Extra travel time, handling delay or closure affecting specified lanes/nodes and times | Recalculate the affected stages, then all later connections. |
| Heavy traffic | Travel-time estimate for a mapped lane/corridor, with observation time and validity | Update the relevant road stage and compare feasible network alternatives. |
| Political or administrative disruption | Concrete border closure, checkpoint delay, strike, carrier cancellation or confirmed restriction | Apply the specific scoped delay or exclusion. Do not invent a generic political-risk penalty. |
| Local operational information | Manager-reported hub congestion, missed service, unavailable vehicle or customs hold | Apply the explicit impact and produce revised options. |

Political news alone is not sufficient to close a lane or assign hours of delay. An unverified report appears for review until it is mapped to a concrete location, period, mode and operational consequence. Confirmed restrictions may exclude routes; additional eligibility checks may be required in a production service.

The supplied CSVs contain no live traffic or weather feeds. In particular, stoerungen's volume percentages are not duration multipliers. For the hackathon, use a labeled replay feed with prepared event messages and automatically run the real recalculation pipeline when a message arrives. This demonstrates automatic behavior on simulated inputs, not live predictive accuracy. A live provider adapter is an optional later addition, requiring suitable corridor coverage, credentials and verified field mapping.

### Event data and lifecycle

Add a disruption_event entity: id, external_id, version, type, source_kind (demo_feed/provider/manager), source_reference, observed_at, received_at, valid_from, valid_until or unknown end, affected_node_ids/lane_ids, affected_mode, effect_type, effect_value, effect_units, verification_status, lifecycle_status, correlation_key, supersedes_event_id, reported_by, reason and updated_at.

Effect types initially: additional_travel_minutes, travel_duration_replacement, additional_handling_minutes, departure_cancellation and closure. Keep raw source values alongside the explicit rule/assumption that translates them into impact. Avoid unsupported percentage confidence scores; show source, observation time, verification state and unknowns.

Expire known-ended events against the demo clock and recalculate affected routes. For unknown-ended closures, use a review_due_at time; flag an overdue review without silently reopening a lane. Stale measurements must be shown as stale, not silently treated as current. Correct, supersede or withdraw events with an audit record rather than deleting their history.

### Automatic processing

1. Receive an event, validate its scope, dates and units, and deduplicate by source/external ID/version.
2. Accept a documented trusted-source event or an explicit manager report. Queue incomplete/unverified reports for review; they can be simulated without modifying the operational state.
3. Match it against the planned time intervals and locations of active saved planning requests. Do not apply Germany-wide weather to an unrelated air segment automatically.
4. Recompute routes from the schedule plus the current event snapshot. Reevaluate all candidates for affected requests; also reevaluate requests whose alternative corridors reopen or improve. The small demo can recompute all saved requests on each change.
5. Propagate changed travel/handling time into missed cut-offs and later services. After waiting changes, recheck which events overlap subsequent stages. Bound the search and return an explicit reason if no feasible itinerary remains.
6. Publish the revised ETA, reason, source, current route and best feasible alternatives. For committed plans, retain the selected route and mark a changed recommendation as awaiting review.
7. Create or update a single review item per plan/revision when the selected route becomes infeasible, an explicit delivery deadline is breached, or a meaningful alternative is proposed. For an uncommitted search, simply update ranked options automatically.

Avoid double counting. If a lane travel-time replacement already includes weather and traffic, do not add the same underlying incident again. Correlate reports, record which impact was applied, and use a documented source/composition policy. Unrelated sequential handling and road delays can accumulate. Overlapping reports without a known relationship require a visible assumption or review, not an unexplained sum. A closure takes precedence over a travel-time delay for the same interval.

Prevent oscillating recommendations with a configurable improvement threshold for optional switches (demo assumption: 30 minutes); bypass it when the current route becomes infeasible. Keep all feasible options visible. Once a manager rejects a recommendation, do not reopen the same unchanged recommendation repeatedly; reconsider it when relevant event/schedule state changes.

This is network/service rerouting: select a different available branch/hub connection. It is not street-by-street truck navigation. A longer road route may arrive sooner if it catches an earlier connection. Never invent a new service because a road exists. MVP recalculation applies to shipments not yet departed. Rerouting a shipment in transit requires a known current location and locked completed legs, which are not in the supplied data.

### Manager interaction

Add a Report disruption form with type, affected lane/node, start/end or review time, structured impact, reason and optional source reference. For example: "Frankfurt hand-over: additional 120 minutes until 18:00; handling backlog confirmed by station manager." The engine computes the revised itinerary; the manager does not manually calculate the final ETA.

Add a review panel showing previous/current estimated arrival, selected route, proposed route, changed segments, triggering events, assumptions and schedule/event revision. Actions: accept recommended route, choose another feasible route, keep the existing feasible route with a reason, correct an event, or request review. An infeasible/closed route cannot be marked feasible merely by rejecting the recommendation; preserve it as blocked until a valid correction or alternative exists.

Store append-only decisions: plan ID, actor, timestamp, action, previous/new route, reason, event snapshot and schedule revision. Before accepting, recompute or check that the recommendation's revisions remain current. Reject stale approvals and display the updated result. For the demo the actor is explicitly a demo manager; production authority cannot be enforced by hiding buttons alone.

### GUI, API and ownership additions

Person A/Codex: add the disruption list with freshness/source labels, manager report form, automatic result refresh, before/after comparison, review actions and decision history. Keep them inside the existing Scenarios & data view and planner side panel to limit scope.

Person B/Claude/Antigravity: add event ingestion/validation, demo replay, event-to-lane mapping, recomputation, deduplication/expiry, persisted planning requests and decisions, and revision checks. A small in-process local event loop plus frontend polling is sufficient for this demo; do not introduce distributed queues.

Extend the shared contract together before implementation:

- POST /api/plans saves a planning request and selected itinerary for subsequent recalculation.
- GET /api/events and POST /api/events list/report structured disruptions; corrections create explicit revisions.
- GET /api/plans/{id} returns selected itinerary, latest ETA, recommendation, reasons and schedule/event revisions.
- POST /api/plans/{id}/decisions records an accept/reject/alternative action with expected revisions and a reason.
- GET /api/plans/{id}/decisions returns the review history.
- Search/plan responses include evaluated_at, event_revision, applied_event_ids and freshness warnings.
- Demo replay advances a visible simulation clock. Replay and temporary scenario events must remain distinguishable from imported historical facts and operational manager reports.

Append this instruction to both coding prompts: "Implement section 13's scoped disruption events, automatic recalculation and manager review as part of the core demo. Coordinate contract additions first. Clearly distinguish demo feed events from live inputs, and distinguish route recommendations from accepted plan changes."

### Additional acceptance checks and demo

Verify weather/traffic changes the ETA without a manager editing it; a missed connection is propagated; an unrelated route stays unaffected; a border closure removes an affected connection; duplicate reports do not duplicate delay; event expiry/correction updates results; unknown-ended closures are not silently cleared; stale feeds are labeled; rejecting a route cannot override a closure; and accepting an out-of-date recommendation requires recalculation. Verify manager reports/decisions persist after reload and include reasons.

Demonstrate one automatic event and one human intervention: replay a traffic incident, show the engine revising arrival and recommending another scheduled path, then have the manager add a local handling delay and review the new recommendation. Include a closure preset using the same event model. Favor this complete loop over adding more dashboards or customer analytics.
