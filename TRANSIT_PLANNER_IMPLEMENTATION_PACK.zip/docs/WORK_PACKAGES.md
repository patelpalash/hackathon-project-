# Work packages and handoffs

Two-day schedule assumes approximately 15-17 focused hours per person, with integration at each gate. It is a planning estimate. If time is shorter, reduce breadth before compromising the tested calculation/review loop. The code is generated in increments; do not hand either assistant the whole project and accept an unverified completion claim.

## Ownership rules

Person A / Codex owns frontend/**, scripts/**, README.md and shared-contract integration. Person B / Claude or Antigravity owns backend/** and data/**. Work on separate checkouts/branches: codex/frontend and codex/backend. Merge the specification commit into both before coding. Person B must not independently change docs/contracts/openapi.json; propose a change listing affected endpoint, reason, fixture and UI effect. Person A applies only mutually accepted changes.

Agents may read the whole repo. They must not reset/revert the other's changes, modify original source CSVs, publish data, deploy, or introduce credentials as part of these work packages. The user asked for a local prototype. Review tools may inspect the other owner's code and report findings; concurrent writers must not share a checkout.

## G0: agree and bootstrap (45 minutes together)

- Read START_HERE, API_CONTRACT, ROUTING_RULES and baseline fixtures.
- Confirm that branch-to-branch scope is shown and simulated inputs are labeled.
- Agree API base /api, ports, folders and python/node versions available on both machines. Record tested versions rather than guessing minimum support.
- Both run docs/tools/validate_spec.py; resolve specification errors before coding.
- A creates frontend Vite React/TypeScript app and commits working npm lockfile. B creates backend virtual environment and pins working FastAPI/Pydantic/uvicorn/pandas/pytest/tzdata versions.

Gate: both can load the same fixture and state exactly why baseline direct and Munich are 840 min and Strasbourg is 900 min.

## A1: frontend shell and typed fixture (1.5 hours)

Create API types matching OpenAPI, api/client.ts with typed errors, main layout, route-search form and result cards. Use a development-only explicit fixture mode switch defaulting off; show a permanent Fixture preview label when on. Render baseline fixture without changing its values. All selection lives in one parent state, referenced by route ID.

Deliver: npm run dev, npm run build and npm run typecheck work; baseline cards display 14h, 14h, 15h in the fixture mode; source and destination labels resolve from network fixture. No stubbed success message for an unimplemented Save button: disable it with a clear explanation until A3.

## B1: database, seed and first real route (2 hours)

Create app factory, settings, JSON error handlers, SQLite schema and init CLI. Load exact network fixture as runtime seed; remove its specification snapshot and generate runtime dataset_id. Add GET health/state/network and POST search for the direct path first, with the real time engine. Scope this temporary single-path stage visibly in development and replace it at B2.

Suggested runtime interface to implement and document:

```
python -m app.cli init --source-dir ../data/raw
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
python -m pytest
```

Default DB path resolves from repository root to data/runtime/transit.db, not process working directory. Optional environment overrides TRANSIT_DB_PATH and TRANSIT_SOURCE_DIR. Init is idempotent and does not reset existing plans. Reset is an explicit CLI/API command. CLI reports unavailable source imports while permitting synthetic seed operation; final delivery must import the provided files.

Gate G1 with A: actual browser request reaches API and renders direct itinerary; backend outage displays error, not fixture fallback. Do this before network visual polish.

## A2: selected route views and schedule editing (2.5 hours)

Build React Flow schematic, timeline with details, route selection synchronization, node/lane editor and data drawer. Use mode/type labels and source descriptions. API network responses drive editors, not hard-coded fixture copies. API timing fields drive the timeline.

Deliver: change a lane duration or cut-off, save with snapshot, refresh and see a recalculated result; selecting another route synchronizes both views. Keyboard navigate form and editor. No arbitrary topology manipulation needed.

## B2: complete routing and source import (3 hours)

Implement cycle-free bounded path enumeration, all departure sequences, timezone rules, cut-offs, validity and calendar pauses. Support profiles and structural no-route states. Implement schedule/node update transactions and source summaries. Run S0, S4-S7 tests plus timezone/validation tests. Add measurable transition count diagnostics to internal logs, not user-facing data.

Gate G2 with A: exact baseline three routes, one-minute cut-off change and schedule persistence work through the real API. Timeline duration sum matches arrival-ready for every result.

## A3: manager controls and automatic refresh (2.5 hours)

Create disruption list and report/correction forms; simulated preset controls; Save plan action; saved-plan detail and accept/keep/defer actions; history. Implement poll/revision refresh, request-race protection, snapshot conflicts, no-route states and reset confirmation. No mutation in React mount effects.

Deliver: accepting a recommendation updates the persisted route, keeping an infeasible route is disabled, and stale approval responses show the new state without silently resubmitting.

## B3: events, saved plans and decisions (3 hours)

Implement exact event model and composition; presets; clock; plans; projections of committed departure sequences; full recomputation; decision history; snapshot/idempotency protections. Complete S1-S3 and manager-loop integration tests. Reuse one engine for searches, projections and recommendations; don't duplicate the delay logic in three handlers.

Gate G3 with A: save baseline direct -> apply traffic -> automatic Munich recommendation -> accept -> manager adds Munich handling -> existing connection infeasible -> Strasbourg alternative -> accept -> show two decisions after reload. No manual ETA editing anywhere.

## A4 / B4: joint hardening and delivery (3-4 hours)

A: browser walkthrough at target sizes, print output, launch scripts and README, production frontend build served by Python, stale state errors, offline checks. B: acceptance suite, transactional rollback, decision concurrency/idempotency, import reconciliation, reset and no-route cases. Both: use a clean checkout/fresh database, follow README literally, run demo twice, then freeze features.

A owns scripts/start-demo.ps1: resolve root from script path, fail with helpful setup instructions if venv/build missing, start the backend foreground in terminal, avoid exposing the server externally. A may call B's documented init/serve CLI, not reimplement database initialization in PowerShell. Keep separate bootstrap and start so presenting does not reinstall dependencies. No mandatory Docker.

Final evidence: tested dependency versions, successful frontend build/typecheck, backend test summary, route fixture comparison, browser steps with observed results, and one-command restart/persistence proof. Record any remaining limitation explicitly. Do not call unexecuted checks passed.

## Reduced schedule if time runs short

Keep one origin/destination, direct plus Munich/Strasbourg alternatives, event presets, one manager report form, accept/keep/defer, timeline and audit history. Hide extra seed scenarios from primary navigation if necessary; do not break their engine tests. Defer geographic map, custom lane schedule editor beyond active toggle, printing and broad source visualization. Maintain a simple source/assumptions panel. Do not defer the automatic-event-to-manager-review loop requested by the user.

## End-of-package assistant report format

Each assistant reports: files changed; behavior now working; exact commands/checks run and their outcomes; unresolved issue; shared-contract change required (yes/no); next package. A screenshot without a working API is not completion. A successful API response without browser integration is not completion.
