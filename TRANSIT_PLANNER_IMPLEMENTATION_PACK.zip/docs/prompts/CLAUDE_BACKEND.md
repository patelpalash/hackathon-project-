# Paste into the Claude or Antigravity implementation task

Build the backend, data layer and deterministic routing engine for our two-person transport-planning hackathon prototype. This is an implementation assignment; work through the packages and verify them rather than only proposing changes.

Read docs/START_HERE.md, BUILD_SPEC.md, API_CONTRACT.md, contracts/openapi.json, ROUTING_RULES.md, WORK_PACKAGES.md and ACCEPTANCE_TESTS.md. Read docs/fixtures for exact examples. These documents supersede tentative older details in PROTOTYPE_PLAN.md. User requirements take precedence.

I am Person B. You own backend/** and data/**. My teammate using Codex owns frontend/**, scripts/** and README.md and integrates shared contract changes. Do not modify the teammate's files or silently rename fields. Work in a separate checkout. If Claude and Antigravity both run, only one writes this checkout; the other reviews/tests or uses a separate branch.

Implement B1 and expose a real health/network/search API immediately so the frontend can connect. Then implement B2, B3 and B4. Use Python, FastAPI, Pydantic, SQLite, pandas, datetime/zoneinfo and tzdata. Implement all agreed endpoints with exact payloads and errors, durable transactions, idempotency and snapshots. Pure engine functions implement all time arithmetic; no duplicate calculation in handlers or UI.

Use the exact synthetic network fixture and provided original CSVs. Preserve source files. The CSVs contain capacity/volume context, not measured ETA labels or live weather. Do not train an ETA model, convert volume percentages to time penalties, or invent origin mappings. Import source summaries and add the explicit simulated event presets.

Follow ROUTING_RULES exactly: at most five lanes and 14 days, schedule/cut-off logic, departure-local zones, actual calendar pauses, grouped event delays, closure/cancellation handling and complete contiguous timelines. Handle every candidate service occurrence needed for correctness; do not use static shortest-distance Dijkstra as the final scheduler. Recalculate a committed itinerary's exact departures separately from recommending new options.

Automatically recompute saved plans on accepted data changes. Manager approvals affect selection and record history. They must not bypass closures or use stale snapshot/plan revisions. Duplicate mutation retries must not duplicate events, delay or decisions. Keep unknown-ended closures blocking when overdue; mark forecasts using overdue estimates visibly. No in-transit rerouting without a location model.

Test all numerical fixtures and API/persistence cases, including the complete manager review loop. Schema-validate representative responses against the shared OpenAPI file. Report expected and actual outputs when a fixture differs; fix logic, not the fixture, unless an independently demonstrated specification error is agreed. Deliver documented init/serve/reset commands and persistent local operation. Do not deploy or transmit datasets externally.

After each package report files changed, behavior demonstrated, commands/tests actually run and outcomes, remaining issue, and any required shared-contract change. If a GUI issue appears, provide the observed API evidence to Person A rather than editing their frontend.
