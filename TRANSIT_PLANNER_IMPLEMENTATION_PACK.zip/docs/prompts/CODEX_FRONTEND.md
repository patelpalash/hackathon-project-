# Paste into the Codex implementation task

Build the frontend and local integration for our two-person transport-planning hackathon prototype. This is an implementation assignment; work through the packages and verify them rather than only proposing changes.

Read docs/START_HERE.md, BUILD_SPEC.md, API_CONTRACT.md, contracts/openapi.json, ROUTING_RULES.md, UI_SPEC.md, WORK_PACKAGES.md and ACCEPTANCE_TESTS.md. Read docs/fixtures for exact examples. These documents supersede tentative older details in PROTOTYPE_PLAN.md. User requirements take precedence.

I am Person A. You own frontend/**, scripts/** and README.md. My teammate owns backend/** and data/** using Claude/Antigravity. Read their code when useful, but do not modify those directories or reset their work. Do not change shared API/schema or fixture expectations without identifying the conflict and coordinating it. Work in a separate checkout from the teammate.

Implement A1 then integrate with B1 immediately, then A2, A3 and A4. Use React, TypeScript, Vite, CSS modules, React Flow and the exact /api contract. Build route search/cards, a synchronized network schematic and timeline, schedule editor, data/assumptions drawer, event/report UI, automatic revision refresh, manager decisions and history. All calculation and persistence comes from the backend. Use development fixtures only behind an explicit off-by-default Fixture preview label; backend failures must never silently use them.

Particular mistakes to prevent: browser-zone conversion of origin-local times; stale async response overriding newer data; UI mutation effects running twice; wrong enum/field names; treating a stale approval as automatically authorized; hiding a failed backend behind fake success; calling synthetic inputs live data. Generate and reuse mutation IDs correctly. The saved selected itinerary and automatically suggested alternative are separate states.

Run typecheck/build and browser verification against the real API after each meaningful milestone. Validate the S0 -> S1 -> accepted Munich -> S2 -> accepted Strasbourg loop, persistence after reload, no-route states, API outage and stale approvals. Package a one-command Windows local launch and an offline demo after dependencies are installed. Do not deploy or transmit source datasets externally.

After each package report files changed, behavior demonstrated, exact checks and outcomes, remaining issue, and any requested contract change. Do not claim a check passed unless run. If the backend is not yet ready, continue independent UI work within the contract and identify the precise endpoint needed; do not invent a competing backend.
