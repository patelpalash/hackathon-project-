# Start here: two-person implementation pack

This pack specifies a working hackathon prototype. It contains design decisions and validation fixtures, not an implemented application. It supersedes tentative implementation details in PROTOTYPE_PLAN.md. The user requirements still take precedence. Fixed scope: React/TypeScript GUI, Python API, automatic disruption recalculation and manager review, with supplied CSV context and explicitly synthetic schedules.

## Read order

1. BUILD_SPEC.md: scope, architecture, persistence and operating conventions.
2. contracts/openapi.json: authoritative wire contract, including exact request/response fields.
3. ROUTING_RULES.md: authoritative calculation and event rules.
4. fixtures/network.json and fixtures/acceptance.json: concrete demonstration data and expected results.
5. UI_SPEC.md: screen behavior and state transitions.
6. WORK_PACKAGES.md: ownership, order, integration gates and definition of done.
7. ACCEPTANCE_TESTS.md: end-to-end checks and algorithm edge cases.
8. prompts/CODEX_FRONTEND.md or prompts/CLAUDE_BACKEND.md: the assignment for the corresponding coding session.

The OpenAPI contract owns field names, enum values and nullability; ROUTING_RULES owns arithmetic and event semantics; fixtures own the exact synthetic example values. If these conflict, report the exact conflict before changing a contract or expected answer. Do not silently choose an interpretation or change expected outputs merely to make a test pass. New dependencies, generated files and implementation code belong in the owners' directories below, not in this specification pack.

## First steps together (30-45 minutes)

- Share the complete repository/specification pack with both people. Person B also needs the seven original CSVs; local paths from Person A's machine are not portable.
- Both read the first four items above. Confirm baseline: Frankfurt -> Kempten is 14 hours direct; Munich alternative is also 14 hours but has an extra transfer; Strasbourg alternative is 15 hours.
- Freeze API version 1.0.0 and do not independently rename fields. Sample dates use September 2026 and an explicit simulation clock, not today's operating state.
- Person A branches for frontend; Person B branches for backend. Use separate checkouts. Person A owns merging and root launch integration.
- Person B first delivers a health endpoint and a real one-path search. Person A first delivers the form and timeline using the checked contract fixture. Connect them during the first work block.

## Files to give each assistant

Give both the entire docs directory and PROTOTYPE_PLAN.md, then paste the relevant prompt. Ask the assistant to implement one work package at a time, run its checks, and report evidence before proceeding. Do not launch competing writers in the same checkout. For Person B, Claude can implement while Antigravity reviews/runs tests, or vice versa.

## Completion evidence

The prototype is complete only when real backend responses drive the GUI, edits and manager decisions persist, the supplied acceptance scenarios pass, and a fresh local launch works with the internet disconnected. Demo fixtures must not silently substitute for a failed backend. A green unit-test run alone does not establish a working GUI.

## What was checked when preparing this pack

The specification fixtures are to be validated for JSON-schema conformance, reference integrity, units and expected timestamp arithmetic by docs/tools/validate_spec.py. That check does not execute a routing implementation. Actual routing, API, persistence and browser tests are the implementation team's responsibility.
